package g32.reto3.Interfaces;

import org.springframework.data.repository.CrudRepository;
import g32.reto3.Modelo.modeloCategoria;


public interface interfaceCategoria extends CrudRepository <modeloCategoria,Integer> {
    
}